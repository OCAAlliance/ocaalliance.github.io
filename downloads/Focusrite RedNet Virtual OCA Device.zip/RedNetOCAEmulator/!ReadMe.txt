Focusrite Audio Engineering Virtual Device Software
===================================================

NOTE
====

By downloading or using this file, or files contained within the containing archive, the user agrees to be bound by the terms of the license 
agreement located at http://ocaalliance.com/EULA as an original contracting party.

PREREQUITES
===========

1. The software has been developed and tested on Windows 7, it should function without issue on newer Windows operating systems.

2. The software requires the installation of an mDNS-SD service to allow the software to advertise its OCA services.  Apple's Bonjour is a good example, although others may function as well.

PACKAGE CONTENTS
================

1. OCALiteRednetVirtual.exe: The RedNet unit emulator.  You give the unit type on the command line, so for an MP8, �OCALiteRednetVirtual.exe red8�.  Other options are red1, red2 and red4.  The program is quit with CTRL-C.

2. Spread sheets that describe the object configurations of the real hardware, plus a linear list of the MP8 virtual unit.

3. A couple of DLL�s that should cover all dependencies of both executables.


