======================================
OCA ALLIANCE (http://ocaalliance.com/)
======================================

OCA PI/MICRO REFERENCE DESIGN
=============================

NOTE
====
By downloading or using this file, or files contained within this archive, the user agrees to be bound by the terms of the license 
agreement located at http://ocaalliance.com/EULA as an original contracting party.


RELEASE NOTES (Released as public source)
=========================================

r60
===

1. OcaLiteBlock now supports nested blocks.
2. BugFix: GET_MEDIACLOCKTYPESSUPPORTED to OcaLiteMediaClockManager as NotImplemented.
3. BugFix: GET_SYSTEM_INTERFACES in OcaLiteStreamNetwork changed from NotImplemented to returning an empty OcaList instead.
4. BugFix: OcaLiteInt8Sensor only one parameter was serialised so min/max values weren't sent to controllers.
5. Added methods to allow setting of m_status and creating the message buffer in Ocp1LiteNetwork. This allows a class to be derived with a specific systemInterfaceID.

r56
===

1. BugFix in OCAMicro\Src\common\SharedLibraries\tinymDNS\mdns.c
	dup_nlabel(): Add one to length of string to copy, ensuring terminating NULL is copied as well.

r53
===

1. BugFix in OCAMicro\Src\common\SharedLibraries\tinymDNS\mdns.c
	create_nlabel(): Removed reliance on allocated memory being zero initialized, ensuring the returned string is always NULL terminated.

r51
===

Initial OCAMicro source release
