/*  By downloading or using this file, the user agrees to be bound by the terms of the license 
 *  agreement located at http://ocaalliance.com/EULA as an original contracting party.
 */

/*
 *  Description         : The logging implementation of the Host Interface for
 *                        a OcaLite enabled platform.
 *
 */

// ---- Include system wide include files ----
#include <stdarg.h>
#include <algorithm>
#include <Stm32CortexM3/lib/UtilLib/Rs232Debug.h>
#include <HostInterfaceLite/OCA/OCF/Logging/IOcfLiteLog.h>

// ---- Include local include files ----

// ---- Helper types and constants ----
/** Maximum amount of characters in one log message */
#define MAX_MESSAGE_SIZE             1024
/** Additional size needed for log message header */
#define MAX_OCA_LOG_MESSAGE_HEADER_SIZE  256
/** Maximum full log message length */
#define MAX_FULL_MESSAGE_LENGTH (MAX_MESSAGE_SIZE + MAX_OCA_LOG_MESSAGE_HEADER_SIZE - 1)


// ---- Helper functions ----

// ---- Local data ----
static UINT8 m_logLevel(0xFF);
//#if !(defined(OCA_DISABLE_OCA_LOG_ERROR) || defined(OCA_DISABLE_OCA_LOG_WARNING) || defined(OCA_DISABLE_OCA_LOG_INFO) || !defined(_DEBUG))
//static bool m_bInitialized(false);
static char m_fullLogMessage[MAX_MESSAGE_SIZE + MAX_OCA_LOG_MESSAGE_HEADER_SIZE];
static UINT8 m_indent;
//#endif

// ---- Class Implementation ----

void OcfLiteLogLogMessage(UINT8 logLevel, const char* type, const char* file, UINT32 lineNumber,
                          const char* message, ...)
{
//#if !(defined(OCA_DISABLE_OCA_LOG_ERROR) || defined(OCA_DISABLE_OCA_LOG_WARNING) || defined(OCA_DISABLE_OCA_LOG_INFO) || !defined(_DEBUG))

#if 0
    if (!m_bInitialized)
    {
        // Initialize peipherals in log path
        Rs232DebugInit();

        m_bInitialized = true;
    }
#endif
    if (logLevel <= m_logLevel)
    {
        // Format and print the message
        va_list argList;
        va_start(argList, message);

        // Check if the message fits into the message buffer, add 1 for terminating '\0'
        UINT32 messageLength(static_cast<UINT32>(::vsnprintf(NULL, 0, message, argList) + 1));
        if (messageLength <= MAX_FULL_MESSAGE_LENGTH)
        {
            INT32 result(::vsprintf(m_fullLogMessage, message, argList));
            bool bAddCarrageReturn = false;  

            if (static_cast<UINT32>(result) <= messageLength)
            {
                // Decrease message indent
                if (m_fullLogMessage[0] == '}')
                {
                    if (m_indent >= 2)
                    {
                        m_indent -= 2;
                    }
                    else
                    {
                        m_indent = 0;
                    }
                }
                if ((logLevel > OCA_LOG_LVL_NONE) &&
                    (m_fullLogMessage[messageLength - 2] != '\r') &&
                    (m_fullLogMessage[messageLength - 2] != '\n'))
                {
                    bAddCarrageReturn = true;
                }

                if (m_fullLogMessage[0] == '.')
                {
                    Rs232DebugPrint("%s%s", &m_fullLogMessage[1], bAddCarrageReturn? "\r\n": "");
                }
                else
                {
                    Rs232DebugPrint("%*s%s%s", m_indent, "", m_fullLogMessage, bAddCarrageReturn? "\r\n": "");
                }

                // Increase message indent
                if (m_fullLogMessage[0] == '{')
                {
                    m_indent += 2;
                }
            }
        }
        va_end(argList);
    }
//#endif
}

void OcfLiteLogSetLogLevel(UINT8 logLevel)
{
    m_logLevel = logLevel;
}
